import { P, a } from "./mermaid-parser.core.CpTH6G7V.js";
export {
  P as PacketModule,
  a as createPacketServices
};
