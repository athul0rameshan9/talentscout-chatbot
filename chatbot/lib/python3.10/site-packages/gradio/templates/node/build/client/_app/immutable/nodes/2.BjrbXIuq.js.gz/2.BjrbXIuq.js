import { W, _ } from "../chunks/2.DunTbUMl.js";
export {
  W as component,
  _ as universal
};
