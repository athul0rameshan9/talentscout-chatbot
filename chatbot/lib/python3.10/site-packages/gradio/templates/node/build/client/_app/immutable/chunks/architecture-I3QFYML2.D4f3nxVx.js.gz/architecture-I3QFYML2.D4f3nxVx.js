import { A, e } from "./mermaid-parser.core.CpTH6G7V.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
