import { I, c } from "./mermaid-parser.core.CpTH6G7V.js";
export {
  I as InfoModule,
  c as createInfoServices
};
